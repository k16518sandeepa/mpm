import json
import asyncio
from telethon import TelegramClient, events, Button
import os

# --- CONFIG ---
API_ID = 7237826
API_HASH = "b99b48799d998f6219daa8927cb33059"
BOT_TOKEN = "8464388414:AAFKaTBGc9BNp40znbNC25UD3oqFabsqWnI"
MOVIES_FILE = "movies.json"
AUTO_DELETE = 600  # 10 minutes
ARCHIVE_CHANNEL = "mpmstorelk"  # your archive channel username

# --- Load / Save JSON ---
def load_movies():
    if not os.path.exists(MOVIES_FILE):
        with open(MOVIES_FILE, "w") as f:
            json.dump({}, f)
    with open(MOVIES_FILE, "r") as f:
        return json.load(f)

def save_movies(data):
    with open(MOVIES_FILE, "w") as f:
        json.dump(data, f, indent=2)

movies = load_movies()

# --- Create client ---
bot = TelegramClient('mpm_indexer', API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# --- Auto-delete helper ---
async def auto_delete(message):
    await asyncio.sleep(AUTO_DELETE)
    try:
        await message.delete()
    except:
        pass

# --- Index new files in archive channel ---
@bot.on(events.NewMessage(incoming=True, func=lambda e: e.chat and e.chat.username == ARCHIVE_CHANNEL))
async def index_new_file(event):
    if event.file:
        name = event.file.name or "Unknown"
        movies[name.lower()] = {
            "chat_id": event.chat_id,
            "msg_id": event.message.id,
            "type": "file"
        }
        save_movies(movies)
        print(f"[INDEXED] {name}")

# --- /start command ---
@bot.on(events.NewMessage(pattern='/start'))
async def start_cmd(event):
    await event.reply(
        "👋 Hello! I’m MPM Smart Indexer.\n\n"
        "Just type a movie, anime, or series name — no commands needed.\n"
        "I’ll search our archive and send matching files 🎬📺"
    )

# --- Search messages (substring match) ---
@bot.on(events.NewMessage(incoming=True))
async def search_movie(event):
    query = event.raw_text.strip().lower()
    if not query or query.startswith("/"):
        return

    found = False
    for name, info in movies.items():
        if query in name:  # simple substring match
            found = True
            if event.is_group:
                # Group chat: show button
                buttons = [Button.inline("📥 Get File", data=name)]
                await event.reply("Click below to receive file in private chat:", buttons=buttons)
            else:
                # Private chat: send directly without forward tag
                msg = await bot.send_file(event.sender_id,
                                          file=await bot.download_media(await bot.get_messages(info["chat_id"], ids=info["msg_id"])))
                asyncio.create_task(auto_delete(msg))
            break

    if not found:
        await event.reply("❌ No results found for your query.")

# --- Button handler ---
@bot.on(events.CallbackQuery)
async def callback(event):
    query = event.data.decode("utf-8")
    if query in movies:
        info = movies[query]
        msg = await bot.send_file(event.sender_id,
                                  file=await bot.download_media(await bot.get_messages(info["chat_id"], ids=info["msg_id"])))
        asyncio.create_task(auto_delete(msg))
        await event.answer("File sent privately! ✅")
    else:
        await event.answer("❌ File not found.")

print("🤖 MPM Smart Indexer running with auto-delete & group buttons...")
bot.run_until_disconnected()
